

<?php $__env->startSection('heading', 'Online Polls'); ?>
<?php $__env->startSection('button'); ?>
    <a href="<?php echo e(route('admin_online_poll_create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Add</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="section-body">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="example1">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Question</th>
                                        <th>Yes Vote</th>
                                        <th>No Vote</th>
                                        <th>Language</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $online_poll_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($row->question); ?></td>
                                            <td><?php echo e($row->yes_vote); ?></td>
                                            <td><?php echo e($row->no_vote); ?></td>
                                            <td><?php echo e($row->rLanguage->name); ?></td>
                                            <td class="pt_10 pb_10">
                                                <a href="<?php echo e(route('admin_online_poll_edit', $row->id)); ?>"
                                                    class="btn btn-primary">Edit</a>
                                                <a href="<?php echo e(route('admin_online_poll_delete', $row->id)); ?>" class="btn btn-danger"
                                                    onClick="return confirm('Are you sure?');">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Udemy\Laravel\news_portal_project\resources\views/admin/online_poll_show.blade.php ENDPATH**/ ?>