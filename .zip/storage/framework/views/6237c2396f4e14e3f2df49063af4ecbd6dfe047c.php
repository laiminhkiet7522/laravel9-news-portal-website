

<?php $__env->startSection('heading', 'Dashboard'); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="row">
        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="fab fa-atlassian"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Total News Categories</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_category); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-success">
                    <i class="fab fa-bandcamp"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Total SubCategory</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_subcategory); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-danger">
                    <i class="fas fa-newspaper"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Total News</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_news); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-info">
                    <i class="fas fa-camera"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Total Photos</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_photo); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-warning">
                    <i class="fas fa-video"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Total Videos</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_video); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="fas fa-question-circle"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Total Faq</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_faq); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-success">
                    <i class="fas fa-vote-yea"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Total Polls</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_poll); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-danger">
                    <i class="fab fa-google-drive"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Total Live Channel</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_channel); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-info">
                    <i class="fas fa-users"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>Total Subscribers</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_subscriber); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Udemy\Laravel\news_portal_project\resources\views/admin/home.blade.php ENDPATH**/ ?>