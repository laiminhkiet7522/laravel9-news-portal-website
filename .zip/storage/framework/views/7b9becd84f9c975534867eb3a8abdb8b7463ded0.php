

<?php $__env->startSection('heading', 'Add Language'); ?>
<?php $__env->startSection('button'); ?>
    <a href="<?php echo e(route('admin_language_show')); ?>" class="btn btn-primary"><i class="fas fa-eye"></i> View</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="section-body">
        <form action="<?php echo e(route('admin_language_store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group mb-3">
                                <label>Name *</label> 
                                <input type="text" class="form-control" name="name">
                            </div>
                            <div class="form-group mb-3">
                                <label>Short Name *</label> 
                                <input type="text" class="form-control" name="short_name">
                            </div>
                            <div class="form-group mb-3">
                                <label>Is Default?</label>
                                <select name="is_default" class="form-control">
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Udemy\Laravel\news_portal_project\resources\views/admin/language_create.blade.php ENDPATH**/ ?>