

<?php $__env->startSection('heading', 'Edit Live Channel'); ?>
<?php $__env->startSection('button'); ?>
    <a href="<?php echo e(route('admin_live_channel_show')); ?>" class="btn btn-primary"><i class="fas fa-eye"></i> View</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="section-body">
        <form action="<?php echo e(route('admin_live_channel_update', $live_channel_data->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group mb-3">
                                <label>Video ID *</label>
                                <input type="text" class="form-control" name="video_id"
                                    value="<?php echo e($live_channel_data->video_id); ?>">
                            </div>
                            <div class="form-group mb-3">
                                <label>Heading *</label>
                                <input type="text" class="form-control" name="heading"
                                    value="<?php echo e($live_channel_data->heading); ?>">
                            </div>
                            <div class="form-group mb-3">
                                <label>Select Language</label>
                                <select name="language_id" class="form-control">
                                    <?php $__currentLoopData = $global_language_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->id); ?>"
                                            <?php if($row->id == $live_channel_data->language_id): ?> selected <?php endif; ?>><?php echo e($row->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Udemy\Laravel\news_portal_project\resources\views/admin/live_channel_edit.blade.php ENDPATH**/ ?>