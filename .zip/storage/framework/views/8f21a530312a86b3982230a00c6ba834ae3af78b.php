

<?php $__env->startSection('main_content'); ?>
    <div class="page-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo e(ALL_POST_OF); ?> <?php echo e($updated_date); ?></h2>
                    <nav class="breadcrumb-container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(HOME); ?></a></li>
                            <li class="breadcrumb-item"><?php echo e(ARCHIVE); ?></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($updated_date); ?>

                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6">
                    <div class="category-page">
                        <div class="row">
                            <?php if(count($post_data_archive)): ?>
                                <?php $__currentLoopData = $post_data_archive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-6 col-md-12">
                                        <div class="category-page-post-item">
                                            <div class="photo">
                                                <img src="<?php echo e(asset('uploads/' . $item->post_photo)); ?>" alt="">
                                            </div>
                                            <div class="category">
                                                <span
                                                    class="badge bg-success"><?php echo e($item->rSubCategory->sub_category_name); ?></span>
                                            </div>
                                            <h3><a href="<?php echo e(route('news_detail', $item->id)); ?>"><?php echo e($item->post_title); ?></a>
                                            </h3>
                                            <div class="date-user">
                                                <div class="user">
                                                    <?php if($item->author_id == 0): ?>
                                                        <?php
                                                            $user_data = \App\Models\Admin::where('id', $item->admin_id)->first();
                                                        ?>
                                                    <?php else: ?>
                                                        <?php
                                                            $user_data = \App\Models\Author::where('id', $item->author_id)->first();
                                                        ?>
                                                    <?php endif; ?>
                                                    <a href="javascript:void;"><?php echo e($user_data->name); ?></a>
                                                </div>
                                                <div class="date">
                                                    <?php
                                                        $ts = strtotime($item->updated_at);
                                                        $updated_date = date('d F, Y', $ts);
                                                    ?>
                                                    <a href="javascript:void;"><?php echo e($updated_date); ?></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <span class="text-danger"><?php echo e(NO_POST_FOUND); ?></span>
                            <?php endif; ?>
                            <div class="col-md-12">
                                <?php echo e($post_data_archive->links()); ?>

                            </div>

                        </div>
                    </div>

                </div>
                <div class="col-lg-4 col-md-6 sidebar-col">
                    <?php echo $__env->make('front.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Udemy\Laravel\news_portal_project\resources\views/front/archive.blade.php ENDPATH**/ ?>