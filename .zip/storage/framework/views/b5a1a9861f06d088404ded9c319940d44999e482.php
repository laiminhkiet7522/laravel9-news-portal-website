

<?php $__env->startSection('main_content'); ?>
    <div class="page-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo e(VIDEO_GALLERY); ?></h2>
                    <nav class="breadcrumb-container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(HOME); ?></a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(VIDEO_GALLERY); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="video-gallery">
                <div class="row">
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4">
                            <div class="video-thumb">
                                <img src="http://img.youtube.com/vi/<?php echo e($item->video_id); ?>/0.jpg" alt="">
                                <div class="bg"></div>
                                <div class="icon">
                                    <a href="http://www.youtube.com/watch?v=<?php echo e($item->video_id); ?>" class="video-button"><i
                                            class="fas fa-play"></i></a>
                                </div>
                            </div>
                            <div class="video-caption">
                                <a href="javascript:void;"><?php echo e($item->caption); ?></a>
                            </div>
                            <div class="video-date">
                                <?php
                                    $ts = strtotime($item->updated_at);
                                    $updated_date = date('d F, Y', $ts);
                                ?>
                                <i class="fas fa-calendar-alt"></i> <?php echo e($updated_date); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12">
                        <?php echo e($videos->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Udemy\Laravel\news_portal_project\resources\views/front/video_gallery.blade.php ENDPATH**/ ?>