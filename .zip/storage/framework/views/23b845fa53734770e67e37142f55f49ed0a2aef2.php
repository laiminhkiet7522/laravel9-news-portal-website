

<?php $__env->startSection('main_content'); ?>
    <div class="page-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo e(PREVIOUS_POLLS); ?></h2>
                    <nav class="breadcrumb-container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(HOME); ?></a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(PREVIOUS_POLLS); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php $__currentLoopData = $online_poll_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($loop->iteration == 1): ?>
                            <?php continue; ?>
                        <?php endif; ?>
                        <?php
                            $total_vote = $item->yes_vote + $item->no_vote;
                            if ($item->yes_vote == 0) {
                                $total_yes_percentage = 0;
                            } else {
                                $total_yes_percentage = ($item->yes_vote * 100) / $total_vote;
                                $total_yes_percentage = ceil($total_yes_percentage);
                            }
                            if ($item->no_vote == 0) {
                                $total_no_percentage = 0;
                            } else {
                                $total_no_percentage = ($item->no_vote * 100) / $total_vote;
                                $total_no_percentage = ceil($total_no_percentage);
                            }
                        ?>
                        <div class="poll-item">
                            <div class="question">
                                <?php echo e(QUESTION); ?>: <?php echo e($item->question); ?>

                            </div>
                            <div class="poll-date">
                                <?php
                                    $ts = strtotime($item->created_at);
                                    $created_date = date('d F, y', $ts);
                                ?>
                                <b><?php echo e(POLL_DATE); ?>:</b> <?php echo e($created_date); ?>

                            </div>
                            <div class="total-vote">
                                <b><?php echo e(TOTAL_VOTES); ?>:</b> <?php echo e($total_vote); ?>

                            </div>
                            <div class="poll-result">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <tr>
                                            <td><?php echo e(YES); ?> (<?php echo e($item->yes_vote); ?>)</td>
                                            <td>
                                                <div class="progress">
                                                    <div class="progress-bar bg-success" role="progressbar"
                                                        style="width: <?php echo e($total_yes_percentage); ?>%" aria-valuenow="<?php echo e($total_yes_percentage); ?>" aria-valuemin="0"
                                                        aria-valuemax="100"><?php echo e($total_yes_percentage); ?>%</div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(NO); ?> (<?php echo e($item->no_vote); ?>)</td>
                                            <td>
                                                <div class="progress">
                                                    <div class="progress-bar bg-danger" role="progressbar"
                                                        style="width: <?php echo e($total_no_percentage); ?>%" aria-valuenow="<?php echo e($total_no_percentage); ?>" aria-valuemin="0"
                                                        aria-valuemax="100"><?php echo e($total_no_percentage); ?>%</div>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Udemy\Laravel\news_portal_project\resources\views/front/poll_previous.blade.php ENDPATH**/ ?>